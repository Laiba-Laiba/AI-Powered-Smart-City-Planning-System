"""
Challenge 4: Emergency Routing Under Changing Conditions
Algorithm: A* Search with Dynamic Replanning
Why A*? It guarantees the shortest path (optimal) when heuristic is admissible.
Manhattan distance is admissible (never overestimates) for our grid.
When roads block, we instantly replan from current position.
Alternative: Dijkstra — A* is faster due to heuristic guidance.
LPA* (Lifelong Planning A*) considered for incremental updates.
"""
import heapq
import math
from typing import List, Optional, Dict, Tuple
from city_graph import CityGraph


class DynamicRouter:
    """
    A*-based emergency router with real-time replanning.
    Handles a sequence of targets (civilians to rescue).
    """

    def __init__(self, city: CityGraph):
        self.city = city
        self.current_position: Optional[int] = None
        self.targets: List[int] = []         # All civilians to rescue
        self.visited_targets: List[int] = [] # Already rescued
        self.current_path: List[int] = []    # Current planned path
        self.current_path_cost: float = 0.0
        self.total_distance: float = 0.0
        self.route_history: List[Dict] = []
        self.replanning_count: int = 0

    def initialize(self, start: int, targets: List[int]):
        """Set starting position and list of civilians."""
        self.current_position = start
        self.targets = list(targets)
        self.visited_targets = []
        self.current_path = []
        self.route_history = []
        self.replanning_count = 0
        self.total_distance = 0.0
        self.city.log(f"🚨  Emergency router initialized: {start} → targets {targets}")
        self._plan_next()

    def step(self) -> Dict:
        """
        Advance one step along current path.
        Returns step info dict.
        """
        if not self.current_path or len(self.current_path) < 2:
            # Reached a target or path exhausted
            if self.current_position in self.targets:
                self.targets.remove(self.current_position)
                self.visited_targets.append(self.current_position)
                self.city.log(
                    f"✅  Civilian rescued at node {self.current_position}! "
                    f"Remaining: {self.targets}"
                )
                self._plan_next()
            elif self.targets:
                self._plan_next()

            return {
                "position": self.current_position,
                "path": self.current_path,
                "rescued": list(self.visited_targets),
                "remaining": list(self.targets),
                "done": len(self.targets) == 0,
            }

        # Move one step
        self.current_path.pop(0)
        if self.current_path:
            prev = self.current_position
            self.current_position = self.current_path[0]
            # Calculate step cost
            if self.city.G.has_edge(prev, self.current_position):
                cost = self.city.G.edges[prev, self.current_position].get('cost', 1.0)
                if cost == float('inf'):
                    # Road just got blocked — replan!
                    self.city.log(
                        f"⚡ Road {prev}↔{self.current_position} blocked! Replanning..."
                    )
                    self.current_position = prev
                    self._plan_next()
                    self.replanning_count += 1
                else:
                    self.total_distance += cost

        return {
            "position": self.current_position,
            "path": list(self.current_path),
            "rescued": list(self.visited_targets),
            "remaining": list(self.targets),
            "done": len(self.targets) == 0,
        }

    def notify_road_blocked(self, u: int, v: int):
        """
        Called immediately when a road is blocked.
        If the blocked road is on our current path → replan.
        """
        path_edges = set()
        for i in range(len(self.current_path) - 1):
            a, b = self.current_path[i], self.current_path[i+1]
            path_edges.add((min(a,b), max(a,b)))

        blocked_key = (min(u,v), max(u,v))
        if blocked_key in path_edges:
            self.city.log(
                f"⚡ Blocked road {u}↔{v} is on active route — REPLANNING NOW"
            )
            self._plan_next()
            self.replanning_count += 1

    def _plan_next(self):
        """
        Choose next target (nearest-first greedy) and compute A* path.
        """
        if not self.targets or self.current_position is None:
            return

        # Greedy nearest target
        best_target = None
        best_cost = float('inf')
        for target in self.targets:
            _, cost = self._astar(self.current_position, target)
            if cost < best_cost:
                best_cost = cost
                best_target = target

        if best_target is not None:
            path, cost = self._astar(self.current_position, best_target)
            if path:
                self.current_path = path
                self.current_path_cost = cost
                self.city.log(
                    f"📍 A* route: {self.current_position} → {best_target} "
                    f"(cost={cost:.2f}, {len(path)} hops)"
                )
                self.route_history.append({
                    "from": self.current_position,
                    "to": best_target,
                    "path": list(path),
                    "cost": cost,
                })
            else:
                self.city.log(
                    f"❌ No path from {self.current_position} to {best_target}!"
                )
                # Skip this target
                if best_target in self.targets:
                    self.targets.remove(best_target)

    def _astar(self, src: int, dst: int) -> Tuple[List[int], float]:
        """
        A* search implementation.
        - f(n) = g(n) + h(n)
        - g(n): actual cost from start
        - h(n): Manhattan distance heuristic (admissible)
        Guarantees optimal path when h is admissible.
        """
        if src == dst:
            return [src], 0.0

        # Priority queue: (f_score, g_score, node, path)
        open_heap = []
        heapq.heappush(open_heap, (0.0, 0.0, src, [src]))
        g_scores = {src: 0.0}
        closed = set()

        while open_heap:
            f, g, current, path = heapq.heappop(open_heap)

            if current in closed:
                continue
            closed.add(current)

            if current == dst:
                return path, g

            for neighbor in self.city.G.neighbors(current):
                edge = self.city.G.edges[current, neighbor]
                if edge.get('blocked', False):
                    continue
                cost = edge.get('cost', 1.0)
                if cost == float('inf'):
                    continue

                new_g = g + cost
                if new_g < g_scores.get(neighbor, float('inf')):
                    g_scores[neighbor] = new_g
                    h = self._heuristic(neighbor, dst)
                    new_f = new_g + h
                    heapq.heappush(
                        open_heap,
                        (new_f, new_g, neighbor, path + [neighbor])
                    )

        return [], float('inf')  # No path found

    def _heuristic(self, node: int, goal: int) -> float:
        """
        Manhattan distance heuristic.
        Admissible because it never overestimates actual cost.
        """
        r1 = self.city.G.nodes[node]['row']
        c1 = self.city.G.nodes[node]['col']
        r2 = self.city.G.nodes[goal]['row']
        c2 = self.city.G.nodes[goal]['col']
        return abs(r1 - r2) + abs(c1 - c2)

    def get_status(self) -> Dict:
        return {
            "position": self.current_position,
            "path": list(self.current_path),
            "targets": list(self.targets),
            "rescued": list(self.visited_targets),
            "replanning_count": self.replanning_count,
            "total_distance": round(self.total_distance, 2),
            "done": len(self.targets) == 0,
        }
