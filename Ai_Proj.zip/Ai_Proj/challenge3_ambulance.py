"""
Challenge 3: Ambulance Placement
Algorithm: Genetic Algorithm (Evolutionary Search)
Why GA? The search space is C(N,3) — combinatorially large. GA uses randomness
and evolution (selection, crossover, mutation) to efficiently explore it without
exhaustive search. Minimizes worst-case response time (minimax objective).
Alternative: Simulated Annealing — GA preferred for its population diversity.
"""
import random
import math
from typing import List, Tuple, Dict, Optional
from city_graph import CityGraph, LocationType


NUM_AMBULANCES = 3
POPULATION_SIZE = 60
GENERATIONS = 150
MUTATION_RATE = 0.15
ELITE_SIZE = 8
TOURNAMENT_SIZE = 5


class AmbulancePlacer:
    """
    Genetic Algorithm to optimally place 3 ambulances.
    Fitness: minimize the maximum distance from any citizen node to nearest ambulance.
    """

    def __init__(self, city: CityGraph):
        self.city = city
        self.best_placement: Optional[List[int]] = None
        self.best_fitness: float = float('inf')
        self.fitness_history: List[float] = []
        self._citizen_nodes: List[int] = []
        self._candidate_nodes: List[int] = []
        self._dist_cache: Dict[Tuple, float] = {}

    def place(self) -> List[int]:
        """Run GA and return best ambulance positions."""
        self.city.log("🚑  Starting Ambulance Placement (Genetic Algorithm)...")

        self._citizen_nodes = [
            n for n, d in self.city.G.nodes(data=True)
            if d['population_density'] > 0
        ]
        self._candidate_nodes = list(self.city.G.nodes())

        if len(self._candidate_nodes) < NUM_AMBULANCES:
            self.city.log("⚠️  Too few nodes for ambulance placement.")
            return self._candidate_nodes[:NUM_AMBULANCES]

        # Pre-compute distances
        self._precompute_distances()

        # Initialize population
        population = self._init_population()

        for gen in range(GENERATIONS):
            # Evaluate fitness
            scored = [(self._fitness(ind), ind) for ind in population]
            scored.sort(key=lambda x: x[0])

            best_gen_fit, best_gen_ind = scored[0]
            self.fitness_history.append(best_gen_fit)

            if best_gen_fit < self.best_fitness:
                self.best_fitness = best_gen_fit
                self.best_placement = list(best_gen_ind)

            # Elite preservation
            new_pop = [list(ind) for _, ind in scored[:ELITE_SIZE]]

            # Fill rest via selection + crossover + mutation
            while len(new_pop) < POPULATION_SIZE:
                p1 = self._tournament_select(scored)
                p2 = self._tournament_select(scored)
                child = self._crossover(p1, p2)
                child = self._mutate(child)
                new_pop.append(child)

            population = new_pop

            if gen % 30 == 0:
                self.city.log(
                    f"   GA Gen {gen}: best worst-case distance = {best_gen_fit:.2f}"
                )

        self.city.log(
            f"✅  Ambulances placed at nodes {self.best_placement} "
            f"(worst-case response: {self.best_fitness:.2f})"
        )

        # Mark ambulance positions in graph
        for nid in self.best_placement:
            self.city.G.nodes[nid]['has_ambulance'] = True

        return self.best_placement

    def _precompute_distances(self):
        """Cache shortest distances from all candidates to all citizens."""
        active = self.city.get_active_graph()
        self._dist_cache.clear()
        for cand in self._candidate_nodes:
            lengths = {}
            try:
                lengths = nx_single_source(active, cand)
            except Exception:
                pass
            for cit in self._citizen_nodes:
                self._dist_cache[(cand, cit)] = lengths.get(cit, 9999)

    def _fitness(self, placement: List[int]) -> float:
        """
        Minimax fitness: worst-case distance from any citizen to nearest ambulance.
        Lower is better.
        """
        max_dist = 0.0
        for cit in self._citizen_nodes:
            min_to_amb = min(
                self._dist_cache.get((amb, cit), 9999)
                for amb in placement
            )
            if min_to_amb > max_dist:
                max_dist = min_to_amb
        return max_dist

    def _init_population(self) -> List[List[int]]:
        """Random initial population."""
        pop = []
        for _ in range(POPULATION_SIZE):
            ind = random.sample(self._candidate_nodes, NUM_AMBULANCES)
            pop.append(ind)
        return pop

    def _tournament_select(self, scored: List[Tuple]) -> List[int]:
        """Tournament selection: pick best from random subset."""
        contestants = random.sample(scored, min(TOURNAMENT_SIZE, len(scored)))
        contestants.sort(key=lambda x: x[0])
        return list(contestants[0][1])

    def _crossover(self, p1: List[int], p2: List[int]) -> List[int]:
        """
        Uniform crossover: randomly pick each gene from p1 or p2.
        Ensures no duplicates by filling gaps from the other parent.
        """
        child_set = set()
        combined = []
        for a, b in zip(p1, p2):
            combined.append(random.choice([a, b]))
        # Deduplicate
        seen = set()
        deduped = []
        for g in combined:
            if g not in seen:
                seen.add(g)
                deduped.append(g)
        # Fill to size
        remaining = [n for n in self._candidate_nodes if n not in seen]
        random.shuffle(remaining)
        while len(deduped) < NUM_AMBULANCES and remaining:
            deduped.append(remaining.pop())
        return deduped[:NUM_AMBULANCES]

    def _mutate(self, individual: List[int]) -> List[int]:
        """Random replacement mutation."""
        result = list(individual)
        for i in range(len(result)):
            if random.random() < MUTATION_RATE:
                candidates = [n for n in self._candidate_nodes if n not in result]
                if candidates:
                    result[i] = random.choice(candidates)
        return result

    def get_coverage_map(self) -> Dict[int, float]:
        """Return distance from each node to nearest ambulance (for heatmap)."""
        if not self.best_placement:
            return {}
        coverage = {}
        for cit in self._citizen_nodes:
            min_dist = min(
                self._dist_cache.get((amb, cit), 9999)
                for amb in self.best_placement
            )
            coverage[cit] = min_dist
        return coverage


def nx_single_source(G, source):
    """Wrapper for nx shortest path lengths."""
    import networkx as nx
    try:
        return dict(nx.single_source_dijkstra_path_length(G, source, weight='cost'))
    except Exception:
        return {}
