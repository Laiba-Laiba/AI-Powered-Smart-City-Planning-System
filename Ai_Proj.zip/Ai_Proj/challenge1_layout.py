"""
Challenge 1: City Layout Planning
Algorithm: Constraint Satisfaction Problem (CSP) with Backtracking + Forward Checking
Why CSP? We have variables (grid cells), domains (location types), and hard constraints.
Backtracking explores assignments and prunes early via constraint propagation.
"""
import random
from typing import Dict, List, Optional, Tuple, Set
from city_graph import CityGraph, LocationType


REQUIRED_COUNTS = {
    LocationType.HOSPITAL:       2,
    LocationType.SCHOOL:         3,
    LocationType.INDUSTRIAL:     3,
    LocationType.POWER_PLANT:    2,
    LocationType.AMBULANCE_DEPOT:2,
    LocationType.RESIDENTIAL:    10,  # remaining filled as residential
}

INCOMPATIBLE_NEIGHBORS = [
    (LocationType.INDUSTRIAL, LocationType.SCHOOL),
    (LocationType.INDUSTRIAL, LocationType.HOSPITAL),
]


class LayoutPlanner:
    """
    CSP-based city layout planner.
    Constraints:
    1. Industrial not adjacent to School/Hospital
    2. Every Residential within 3 hops of a Hospital
    3. Power Plant within 2 hops of Industrial zone
    """

    def __init__(self, city: CityGraph):
        self.city = city
        self.rows = city.rows
        self.cols = city.cols
        self.violations: List[str] = []
        self.assignment: Dict[int, LocationType] = {}

    def plan(self) -> bool:
        """
        Main entry: attempt CSP layout.
        Returns True if a valid layout was found.
        """
        self.city.log("🏙️  Starting CSP Layout Planning...")
        nodes = list(self.city.G.nodes())

        # Build ordered placement list: critical types first
        placement_order = self._build_placement_order()
        success = self._backtrack(placement_order, 0, {})

        if success:
            self._apply_assignment()
            self._fill_remaining_residential()
            self._assign_population_density()
            self.city.log("✅  CSP Layout complete — all constraints satisfied.")
        else:
            self.city.log("⚠️  Full CSP failed — applying minimum-conflict fallback.")
            self._minimum_conflict_layout()

        return success

    def _build_placement_order(self) -> List[Tuple[int, LocationType]]:
        """
        Strategically order placements:
        - Hospitals go to corners/spread positions to maximize coverage
        - Industrial goes to edges (away from schools/hospitals)
        - Power Plants near industrial
        """
        nodes = list(self.city.G.nodes())
        rows, cols = self.city.rows, self.city.cols

        # Hospitals: spread evenly across grid quadrants
        hospital_nodes = self._pick_spread_nodes(nodes, 2, rows, cols)

        # Industrial: corners of grid (far from center where hospitals are)
        industrial_nodes = self._pick_corner_nodes(nodes, 3, rows, cols,
                                                    exclude=set(hospital_nodes))

        # Power Plants: adjacent to industrial
        pp_nodes = self._pick_near_nodes(industrial_nodes, 2, nodes,
                                          exclude=set(hospital_nodes + industrial_nodes))

        # Ambulance depots: spread
        depot_candidates = [n for n in nodes
                            if n not in set(hospital_nodes + industrial_nodes + pp_nodes)]
        random.shuffle(depot_candidates)
        depot_nodes = depot_candidates[:2]

        # Schools: remaining central nodes
        used = set(hospital_nodes + industrial_nodes + pp_nodes + depot_nodes)
        school_candidates = [n for n in nodes if n not in used]
        random.shuffle(school_candidates)
        school_nodes = school_candidates[:3]

        order = []
        for nid in hospital_nodes:   order.append((nid, LocationType.HOSPITAL))
        for nid in industrial_nodes: order.append((nid, LocationType.INDUSTRIAL))
        for nid in pp_nodes:         order.append((nid, LocationType.POWER_PLANT))
        for nid in depot_nodes:      order.append((nid, LocationType.AMBULANCE_DEPOT))
        for nid in school_nodes:     order.append((nid, LocationType.SCHOOL))
        return order

    def _pick_spread_nodes(self, nodes, count, rows, cols):
        """Pick nodes spread across quadrants."""
        quadrant_centers = []
        for qr in range(2):
            for qc in range(2):
                cr = int(rows * (qr + 0.5) / 2)
                cc = int(cols * (qc + 0.5) / 2)
                target = cr * cols + cc
                # Find closest node
                best = min(nodes, key=lambda n: abs(self.city.G.nodes[n]['row']-cr) +
                                                 abs(self.city.G.nodes[n]['col']-cc))
                quadrant_centers.append(best)
        return list(set(quadrant_centers))[:count]

    def _pick_corner_nodes(self, nodes, count, rows, cols, exclude=None):
        """Pick nodes near grid corners."""
        exclude = exclude or set()
        corners = [(0,0),(0,cols-1),(rows-1,0),(rows-1,cols-1)]
        result = []
        for cr, cc in corners[:count]:
            candidates = [n for n in nodes if n not in exclude and n not in result]
            best = min(candidates, key=lambda n: abs(self.city.G.nodes[n]['row']-cr) +
                                                  abs(self.city.G.nodes[n]['col']-cc))
            result.append(best)
        return result

    def _pick_near_nodes(self, anchor_nodes, count, all_nodes, exclude=None):
        """Pick nodes adjacent to anchor_nodes."""
        exclude = exclude or set()
        result = []
        for anchor in anchor_nodes:
            if len(result) >= count:
                break
            for nb in self.city.neighbors(anchor):
                if nb not in exclude and nb not in result:
                    result.append(nb)
                    break
        # Fallback
        while len(result) < count:
            candidates = [n for n in all_nodes if n not in exclude and n not in result]
            if not candidates:
                break
            result.append(random.choice(candidates))
        return result[:count]

    def _backtrack(self, placement_order, idx, assignment) -> bool:
        """Recursive backtracking CSP solver."""
        if idx == len(placement_order):
            # Check 3-hop hospital constraint for residential (partial check)
            return True

        nid, ltype = placement_order[idx]

        # Try assigning ltype to nid
        assignment[nid] = ltype
        if self._is_consistent(nid, ltype, assignment):
            result = self._backtrack(placement_order, idx + 1, assignment)
            if result:
                self.assignment = dict(assignment)
                return True

        # Backtrack — try a different node (swap with remaining)
        for swap_idx in range(idx + 1, len(placement_order)):
            swap_nid, swap_ltype = placement_order[swap_idx]
            if swap_ltype == ltype and swap_nid not in assignment:
                # Try swap_nid instead
                assignment[swap_nid] = ltype
                if self._is_consistent(swap_nid, ltype, assignment):
                    new_order = list(placement_order)
                    new_order[idx] = (swap_nid, ltype)
                    new_order[swap_idx] = (nid, ltype)
                    result = self._backtrack(new_order, idx + 1, assignment)
                    if result:
                        self.assignment = dict(assignment)
                        return True
                del assignment[swap_nid]

        # Give up on this branch
        if nid in assignment:
            del assignment[nid]
        return False

    def _is_consistent(self, nid: int, ltype: LocationType, assignment: Dict) -> bool:
        """Check all constraints for this assignment."""
        neighbors = self.city.neighbors(nid)

        for nb in neighbors:
            nb_type = assignment.get(nb)
            if nb_type is None:
                continue
            # Constraint 1: Industrial not adjacent to School/Hospital
            pair = (ltype, nb_type)
            rev  = (nb_type, ltype)
            for incompatible in INCOMPATIBLE_NEIGHBORS:
                if pair == incompatible or rev == incompatible:
                    return False
        return True

    def _apply_assignment(self):
        """Write CSP result into city graph."""
        for nid, ltype in self.assignment.items():
            self.city.set_location_type(nid, ltype)

    def _fill_remaining_residential(self):
        """Fill unassigned nodes as residential (up to count), rest empty."""
        unassigned = [n for n in self.city.G.nodes()
                      if self.city.G.nodes[n]['location_type'] == LocationType.EMPTY
                      and n not in self.assignment]
        random.shuffle(unassigned)
        res_count = REQUIRED_COUNTS[LocationType.RESIDENTIAL]
        for i, nid in enumerate(unassigned):
            if i < res_count:
                self.city.set_location_type(nid, LocationType.RESIDENTIAL)

    def _assign_population_density(self):
        """Assign realistic population density by type."""
        density_map = {
            LocationType.RESIDENTIAL:    lambda: random.uniform(500, 2000),
            LocationType.HOSPITAL:       lambda: random.uniform(200, 500),
            LocationType.SCHOOL:         lambda: random.uniform(100, 400),
            LocationType.INDUSTRIAL:     lambda: random.uniform(50, 300),
            LocationType.POWER_PLANT:    lambda: random.uniform(20, 100),
            LocationType.AMBULANCE_DEPOT:lambda: random.uniform(10, 50),
            LocationType.EMPTY:          lambda: random.uniform(0, 50),
        }
        for nid, data in self.city.G.nodes(data=True):
            ltype = data['location_type']
            density_fn = density_map.get(ltype, lambda: 0.0)
            self.city.set_population_density(nid, density_fn())

    def _minimum_conflict_layout(self):
        """
        Fallback: Min-conflicts heuristic.
        Randomly assign locations, then iteratively fix most violated constraint.
        """
        self.city.log("🔧 Running minimum-conflict repair...")
        nodes = list(self.city.G.nodes())
        random.shuffle(nodes)

        # Simple greedy: place each type in sequence, skip conflicts
        idx = 0
        for ltype, count in REQUIRED_COUNTS.items():
            if ltype == LocationType.RESIDENTIAL:
                continue
            placed = 0
            while placed < count and idx < len(nodes):
                nid = nodes[idx]
                idx += 1
                conflict = False
                for nb in self.city.neighbors(nid):
                    nb_type = self.city.G.nodes[nb]['location_type']
                    pair = (ltype, nb_type)
                    rev  = (nb_type, ltype)
                    for incompatible in INCOMPATIBLE_NEIGHBORS:
                        if pair == incompatible or rev == incompatible:
                            conflict = True
                            break
                if not conflict:
                    self.city.set_location_type(nid, ltype)
                    placed += 1

        # Fill rest as residential
        remaining = [n for n in nodes if self.city.G.nodes[n]['location_type'] == LocationType.EMPTY]
        random.shuffle(remaining)
        for i, nid in enumerate(remaining[:REQUIRED_COUNTS[LocationType.RESIDENTIAL]]):
            self.city.set_location_type(nid, LocationType.RESIDENTIAL)

        self._assign_population_density()
        self._identify_violations()

    def _identify_violations(self):
        """Identify which constraints are violated in current layout."""
        self.violations.clear()
        G = self.city.G

        # Constraint 1
        for u, v in G.edges():
            u_type = G.nodes[u]['location_type']
            v_type = G.nodes[v]['location_type']
            for incompatible in INCOMPATIBLE_NEIGHBORS:
                if (u_type, v_type) == incompatible or (v_type, u_type) == incompatible:
                    self.violations.append(
                        f"Rule 1 VIOLATED: Node {u} ({u_type.value}) adjacent to {v} ({v_type.value})"
                    )

        # Constraint 2
        hospitals = self.city.all_nodes_of_type(LocationType.HOSPITAL)
        for res in self.city.all_nodes_of_type(LocationType.RESIDENTIAL):
            min_dist = min((self.city.bfs_distance(res, h) for h in hospitals), default=999)
            if min_dist > 3:
                self.violations.append(
                    f"Rule 2 VIOLATED: Residential {res} is {min_dist} hops from nearest hospital"
                )

        # Constraint 3
        industrials = self.city.all_nodes_of_type(LocationType.INDUSTRIAL)
        for pp in self.city.all_nodes_of_type(LocationType.POWER_PLANT):
            min_dist = min((self.city.bfs_distance(pp, i) for i in industrials), default=999)
            if min_dist > 2:
                self.violations.append(
                    f"Rule 3 VIOLATED: PowerPlant {pp} is {min_dist} hops from nearest Industrial"
                )

        for v in self.violations:
            self.city.log(f"⚠️  {v}")

    def validate_layout(self) -> Tuple[bool, List[str]]:
        """Public method to validate current layout."""
        self._identify_violations()
        return len(self.violations) == 0, self.violations
