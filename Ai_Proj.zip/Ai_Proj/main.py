#!/usr/bin/env python3
"""
CityMind — Main Launcher
Run: python main.py
Then open: http://localhost:5000
"""
import sys
import os

# Make sure we can find all modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def run_console_demo():
    """
    Console-mode demo: runs full simulation and prints results.
    Useful for testing without the web UI.
    """
    from simulation import SimulationEngine
    import json

    print("=" * 60)
    print("  CityMind — Console Demo Mode")
    print("=" * 60)

    sim = SimulationEngine(rows=10, cols=10)
    sim.initialize()

    print("\n── Running 20-step simulation ──\n")
    for step in range(20):
        snap = sim.step()
        router = snap['router']
        print(
            f"Step {snap['step']:2d} | "
            f"Team@{str(router.get('position','?')):4s} | "
            f"Rescued:{len(router.get('rescued',[]))} | "
            f"Targets:{len(router.get('targets',[]))} | "
            f"Blocked roads:{len(snap['blocked_roads'])} | "
            f"Replanning:{router.get('replanning_count',0)}"
        )

    print("\n── Final Summary ──")
    final = sim._snapshot()
    print(f"Layout violations: checking...")
    valid, viols = sim.layout_planner.validate_layout()
    print(f"  Layout valid: {valid}")
    for v in viols[:5]:
        print(f"  {v}")

    print(f"\nRoad network: {sim.road_optimizer_result}")
    print(f"\nAmbulance final positions: {sim.ambulance_positions}")
    print(f"\nCrime distribution: {final['crime_distribution']}")
    print(f"\nPolice deployed at: {final['police_deployment'][:5]}...")

    print("\n── Event Log (last 15 entries) ──")
    for entry in sim.city.get_log(15):
        print(f"  {entry}")


def run_web():
    """Launch Flask web application."""
    from app import app
    print("=" * 60)
    print("  CityMind — Intelligent Urban Decision System")
    print("  Web UI: http://localhost:5000")
    print("=" * 60)
    app.run(debug=False, host='0.0.0.0', port=5000, threaded=True)


if __name__ == '__main__':
    if '--console' in sys.argv:
        run_console_demo()
    else:
        run_web()
