"""
CityMind Flask Web Application
Serves the interactive city visualization dashboard.
"""
import json
import threading
from flask import Flask, render_template, jsonify, request
from simulation import SimulationEngine

app = Flask(
    __name__,
    template_folder='templates',
    static_folder='static'
)

# Global simulation instance
sim: SimulationEngine = None
sim_lock = threading.Lock()


def get_sim():
    global sim
    if sim is None:
        sim = SimulationEngine(rows=10, cols=10)
    return sim


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/initialize', methods=['POST'])
def initialize():
    with sim_lock:
        s = get_sim()
        if not s.initialized:
            s.initialize()
        snap = s._snapshot()
    return jsonify({"status": "ok", "snapshot": snap})


@app.route('/api/step', methods=['POST'])
def step():
    with sim_lock:
        s = get_sim()
        if not s.initialized:
            s.initialize()
        snap = s.step()
    return jsonify({"status": "ok", "snapshot": snap})


@app.route('/api/reset', methods=['POST'])
def reset():
    global sim
    with sim_lock:
        data = request.json or {}
        rows = data.get('rows', 10)
        cols = data.get('cols', 10)
        sim = SimulationEngine(rows=rows, cols=cols)
    return jsonify({"status": "reset"})


@app.route('/api/block_road', methods=['POST'])
def block_road():
    data = request.json or {}
    u = data.get('u')
    v = data.get('v')
    with sim_lock:
        s = get_sim()
        if u is not None and v is not None:
            s.city.block_road(int(u), int(v), reason="Manual")
            s.router.notify_road_blocked(int(u), int(v))
    return jsonify({"status": "blocked"})


@app.route('/api/snapshot', methods=['GET'])
def snapshot():
    with sim_lock:
        s = get_sim()
        snap = s._snapshot()
    return jsonify(snap)


@app.route('/api/log', methods=['GET'])
def get_log():
    with sim_lock:
        s = get_sim()
        log = s.city.get_log(100)
    return jsonify({"log": log})


@app.route('/api/validate', methods=['GET'])
def validate():
    with sim_lock:
        s = get_sim()
        valid, violations = s.layout_planner.validate_layout()
    return jsonify({"valid": valid, "violations": violations})


@app.route('/api/stats', methods=['GET'])
def stats():
    with sim_lock:
        s = get_sim()
        router_status = s.router.get_status()
        coverage = s.ambulance_placer.get_coverage_map() if s.initialized else {}
        crime_summary = s.crime_predictor.get_cluster_summary() if s.initialized else []

    return jsonify({
        "router": router_status,
        "coverage_map": {str(k): v for k, v in coverage.items()},
        "cluster_summary": crime_summary,
        "road_network": s.road_optimizer_result if s.initialized else {},
    })


if __name__ == '__main__':
    print("=" * 60)
    print("  CityMind — Intelligent City Decision System")
    print("  Open: http://localhost:5000")
    print("=" * 60)
    app.run(debug=False, host='0.0.0.0', port=5000, threaded=True)
