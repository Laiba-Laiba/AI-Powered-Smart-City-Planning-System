"""
CityMind - Shared City Graph
Single source of truth for the entire system.
All modules read/write through this shared graph.
"""
import networkx as nx
import numpy as np
import random
from enum import Enum
from typing import Optional, Dict, List, Tuple, Set


class LocationType(Enum):
    RESIDENTIAL  = "Residential"
    HOSPITAL     = "Hospital"
    SCHOOL       = "School"
    INDUSTRIAL   = "Industrial"
    POWER_PLANT  = "PowerPlant"
    AMBULANCE_DEPOT = "AmbulanceDepot"
    EMPTY        = "Empty"


LOCATION_COLORS = {
    LocationType.RESIDENTIAL:    "#4A90D9",
    LocationType.HOSPITAL:       "#E74C3C",
    LocationType.SCHOOL:         "#F39C12",
    LocationType.INDUSTRIAL:     "#7F8C8D",
    LocationType.POWER_PLANT:    "#8E44AD",
    LocationType.AMBULANCE_DEPOT:"#27AE60",
    LocationType.EMPTY:          "#2C3E50",
}

RISK_COLORS = {
    "High":   "#E74C3C",
    "Medium": "#F39C12",
    "Low":    "#27AE60",
    "Unknown":"#95A5A6",
}

ROAD_COST = {
    "standard":    1.0,
    "residential": 0.8,
    "blocked":     float('inf'),
}


class CityGraph:
    """
    Shared city graph — the single source of truth.
    Represents the city as a grid-based undirected weighted graph.
    """

    def __init__(self, rows: int = 10, cols: int = 10):
        self.rows = rows
        self.cols = cols
        self.G: nx.Graph = nx.Graph()
        self._blocked_edges: Set[Tuple] = set()
        self._event_log: List[str] = []
        self._observers: List = []   # callbacks notified on changes
        self._build_grid()

    # ------------------------------------------------------------------ #
    #  Grid construction                                                   #
    # ------------------------------------------------------------------ #
    def _build_grid(self):
        """Create nodes and edges for a grid graph."""
        for r in range(self.rows):
            for c in range(self.cols):
                nid = self._nid(r, c)
                self.G.add_node(nid,
                    row=r, col=c,
                    location_type=LocationType.EMPTY,
                    population_density=0.0,
                    risk_index=0.5,
                    risk_label="Unknown",
                    accessibility=True,
                    cluster_id=-1,
                )

        # Horizontal and vertical edges
        for r in range(self.rows):
            for c in range(self.cols):
                if c + 1 < self.cols:
                    self._add_road(self._nid(r, c), self._nid(r, c+1))
                if r + 1 < self.rows:
                    self._add_road(self._nid(r, c), self._nid(r+1, c))

    def _add_road(self, u, v, base_cost: float = ROAD_COST["standard"]):
        key = (min(u,v), max(u,v))
        self.G.add_edge(u, v, cost=base_cost, blocked=False,
                        base_cost=base_cost, key=key)

    def _nid(self, r: int, c: int) -> int:
        return r * self.cols + c

    def node_pos(self, nid: int) -> Tuple[int,int]:
        return self.G.nodes[nid]['row'], self.G.nodes[nid]['col']

    # ------------------------------------------------------------------ #
    #  Node property setters (notify observers)                           #
    # ------------------------------------------------------------------ #
    def set_location_type(self, nid: int, ltype: LocationType):
        self.G.nodes[nid]['location_type'] = ltype
        # Residential roads get cheaper cost
        if ltype == LocationType.RESIDENTIAL:
            for nb in self.G.neighbors(nid):
                self._update_edge_cost(nid, nb)
        self._notify(f"Location {nid} set to {ltype.value}")

    def _update_edge_cost(self, u, v):
        u_type = self.G.nodes[u]['location_type']
        v_type = self.G.nodes[v]['location_type']
        if u_type == LocationType.RESIDENTIAL or v_type == LocationType.RESIDENTIAL:
            base = ROAD_COST["residential"]
        else:
            base = ROAD_COST["standard"]
        if not self.G.edges[u, v]['blocked']:
            self.G.edges[u, v]['cost'] = base
        self.G.edges[u, v]['base_cost'] = base

    def set_population_density(self, nid: int, density: float):
        self.G.nodes[nid]['population_density'] = density

    def set_risk(self, nid: int, risk_index: float, risk_label: str):
        self.G.nodes[nid]['risk_index'] = risk_index
        self.G.nodes[nid]['risk_label'] = risk_label
        # Update edge costs with risk multiplier
        for nb in self.G.neighbors(nid):
            e = self.G.edges[nid, nb]
            if not e['blocked']:
                multiplier = 1.0 + 0.5 * risk_index  # High risk → higher cost
                e['cost'] = e['base_cost'] * multiplier
        self._notify(f"Node {nid} risk updated → {risk_label} ({risk_index:.2f})")

    # ------------------------------------------------------------------ #
    #  Road blocking / unblocking                                         #
    # ------------------------------------------------------------------ #
    def block_road(self, u: int, v: int, reason: str = "Flood"):
        if self.G.has_edge(u, v):
            self.G.edges[u, v]['blocked'] = True
            self.G.edges[u, v]['cost'] = float('inf')
            self._blocked_edges.add((min(u,v), max(u,v)))
            msg = f"⚠️  Road {u}↔{v} BLOCKED ({reason})"
            self.log(msg)
            self._notify(msg)

    def unblock_road(self, u: int, v: int):
        if self.G.has_edge(u, v):
            self.G.edges[u, v]['blocked'] = False
            base = self.G.edges[u, v]['base_cost']
            self.G.edges[u, v]['cost'] = base
            key = (min(u,v), max(u,v))
            self._blocked_edges.discard(key)
            msg = f"✅  Road {u}↔{v} UNBLOCKED"
            self.log(msg)
            self._notify(msg)

    def get_active_graph(self) -> nx.Graph:
        """Return subgraph with only non-blocked edges."""
        active = nx.Graph()
        active.add_nodes_from(self.G.nodes(data=True))
        for u, v, data in self.G.edges(data=True):
            if not data['blocked']:
                active.add_edge(u, v, **data)
        return active

    # ------------------------------------------------------------------ #
    #  Pathfinding helpers                                                 #
    # ------------------------------------------------------------------ #
    def shortest_path(self, src: int, dst: int):
        """A* shortest path using current costs (blocked edges excluded)."""
        active = self.get_active_graph()
        try:
            path = nx.astar_path(active, src, dst, heuristic=self._heuristic,
                                 weight='cost')
            cost = nx.astar_path_length(active, src, dst,
                                        heuristic=self._heuristic, weight='cost')
            return path, cost
        except nx.NetworkXNoPath:
            return None, float('inf')

    def _heuristic(self, u, v):
        """Manhattan distance heuristic (admissible for grid)."""
        r1, c1 = self.G.nodes[u]['row'], self.G.nodes[u]['col']
        r2, c2 = self.G.nodes[v]['row'], self.G.nodes[v]['col']
        return abs(r1-r2) + abs(c1-c2)

    def bfs_distance(self, src: int, dst: int) -> int:
        """Unweighted BFS distance (hop count)."""
        active = self.get_active_graph()
        try:
            return nx.shortest_path_length(active, src, dst)
        except nx.NetworkXNoPath:
            return 999

    def all_nodes_of_type(self, ltype: LocationType) -> List[int]:
        return [n for n, d in self.G.nodes(data=True)
                if d['location_type'] == ltype]

    def neighbors(self, nid: int) -> List[int]:
        return list(self.G.neighbors(nid))

    # ------------------------------------------------------------------ #
    #  Observers / logging                                                 #
    # ------------------------------------------------------------------ #
    def register_observer(self, callback):
        self._observers.append(callback)

    def _notify(self, msg: str):
        for cb in self._observers:
            try: cb(msg)
            except: pass

    def log(self, msg: str):
        self._event_log.append(msg)
        if len(self._event_log) > 500:
            self._event_log = self._event_log[-500:]

    def get_log(self, n: int = 50) -> List[str]:
        return self._event_log[-n:]

    def get_node_data(self) -> List[Dict]:
        result = []
        for nid, data in self.G.nodes(data=True):
            result.append({
                "id": nid,
                "row": data['row'],
                "col": data['col'],
                "type": data['location_type'].value,
                "population": data['population_density'],
                "risk_index": data['risk_index'],
                "risk_label": data['risk_label'],
                "accessible": data['accessibility'],
                "cluster_id": data.get('cluster_id', -1),
                "color": LOCATION_COLORS[data['location_type']],
            })
        return result

    def get_edge_data(self) -> List[Dict]:
        result = []
        for u, v, data in self.G.edges(data=True):
            result.append({
                "u": u, "v": v,
                "cost": data['cost'] if not data['blocked'] else -1,
                "blocked": data['blocked'],
            })
        return result
