"""
Challenge 2: Road Network Optimization
Algorithm: Modified Kruskal's MST + Supplementary Edge Addition for Redundancy
Why? MST gives minimum-cost connected network. We then ensure 2 independent paths
between Hospital and Ambulance Depot by adding the next cheapest edge if needed.
Alternative considered: Prim's algorithm — both give MST, Kruskal's easier to
augment with the redundancy constraint.
"""
import networkx as nx
from typing import List, Tuple, Optional, Dict
from city_graph import CityGraph, LocationType

class RoadOptimizer:
    def __init__(self, city: CityGraph):
        self.city = city
        self.mst_edges: List[Tuple[int, int, float]] = []
        self.extra_edges: List[Tuple[int, int, float]] = []
        self.primary_hospital: Optional[int] = None
        self.ambulance_depot: Optional[int] = None

    def optimize(self) -> Dict:
        self.city.log("🛣️ Starting Road Network Optimization (Kruskal's MST)...")

        hospitals = self.city.all_nodes_of_type(LocationType.HOSPITAL)
        depots = self.city.all_nodes_of_type(LocationType.AMBULANCE_DEPOT)

        if not hospitals or not depots:
            self.city.log("⚠️ No hospitals or depots found — skipping road optimization.")
            return {"status": "skipped"}

        self.primary_hospital = hospitals[0]
        self.ambulance_depot = depots[0]

        self.mst_edges = self._kruskal_mst()
        network_edges = list(self.mst_edges)

        if not self._check_redundancy(network_edges):
            self.city.log("🔧 Adding redundancy edge for Hospital ↔ Depot paths...")
            added = self._add_redundancy_edges_until_valid(network_edges)
            if not added:
                self.city.log("⚠️ Could not guarantee two independent routes with available edges.")

        total_cost = sum(c for _, _, c in self.mst_edges) + sum(c for _, _, c in self.extra_edges)

        self.city.log(
            f"✅ Road network built: {len(self.mst_edges)} MST edges, "
            f"{len(self.extra_edges)} redundancy edges. Total cost: {total_cost:.2f}"
        )

        return {
            "mst_edges": len(self.mst_edges),
            "extra_edges": len(self.extra_edges),
            "total_cost": total_cost,
            "hospital": self.primary_hospital,
            "depot": self.ambulance_depot,
            "redundancy": self._check_redundancy(self.mst_edges + self.extra_edges),
            "paths": self.get_paths_hospital_to_depot()
        }

    def _kruskal_mst(self) -> List[Tuple[int, int, float]]:
        all_edges = []
        for u, v, data in self.city.G.edges(data=True):
            if data.get('blocked'):
                continue
            cost = data.get('cost', 1.0)
            if cost != float('inf'):
                all_edges.append((cost, u, v))
        all_edges.sort()

        parent = {n: n for n in self.city.G.nodes()}
        rank = {n: 0 for n in self.city.G.nodes()}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            px, py = find(x), find(y)
            if px == py:
                return False
            if rank[px] < rank[py]:
                px, py = py, px
            parent[py] = px
            if rank[px] == rank[py]:
                rank[px] += 1
            return True

        mst = []
        for cost, u, v in all_edges:
            if union(u, v):
                mst.append((u, v, cost))
            if len(mst) == self.city.G.number_of_nodes() - 1:
                break
        return mst

    def _check_redundancy(self, edges: List[Tuple[int, int, float]]) -> bool:
        if self.primary_hospital is None or self.ambulance_depot is None:
            return False

        G = nx.Graph()
        for u, v, c in edges:
            G.add_edge(u, v, weight=c)

        if not G.has_node(self.primary_hospital) or not G.has_node(self.ambulance_depot):
            return False

        try:
            return nx.edge_connectivity(G, self.primary_hospital, self.ambulance_depot) >= 2
        except Exception:
            return False

    def _add_redundancy_edges_until_valid(self, existing_edges: List[Tuple[int, int, float]]) -> bool:
        existing_set = {(min(u, v), max(u, v)) for u, v, _ in existing_edges}
        candidates = []

        for u, v, data in self.city.G.edges(data=True):
            key = (min(u, v), max(u, v))
            if key not in existing_set and not data.get('blocked') and data.get('cost', 1.0) != float('inf'):
                candidates.append((data.get('cost', 1.0), u, v))

        candidates.sort()

        for cost, u, v in candidates:
            trial = existing_edges + self.extra_edges + [(u, v, cost)]
            if self._check_redundancy(trial):
                self.extra_edges.append((u, v, cost))
                self.city.log(f"✅ Redundancy edge added: {u}↔{v} (cost={cost:.2f})")
                return True

        return False

    def get_active_edges(self) -> List[Tuple[int, int, float]]:
        return self.mst_edges + self.extra_edges

    def get_paths_hospital_to_depot(self) -> List[List[int]]:
        if self.primary_hospital is None or self.ambulance_depot is None:
            return []
        G = nx.Graph()
        for u, v, c in self.get_active_edges():
            G.add_edge(u, v, weight=c)
        try:
            return list(nx.edge_disjoint_paths(G, self.primary_hospital, self.ambulance_depot))[:2]
        except Exception:
            return []
