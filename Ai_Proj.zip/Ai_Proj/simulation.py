"""
CityMind Simulation Engine
Runs the 20-step integrated simulation, tying all 5 challenges together.
"""
import random
import time
from typing import List, Dict, Optional, Callable
from city_graph import CityGraph, LocationType
from challenge1_layout import LayoutPlanner
from challenge2_roads import RoadOptimizer
from challenge3_ambulance import AmbulancePlacer
from challenge4_routing import DynamicRouter
from challenge5_crime import CrimeRiskPredictor


class SimulationEngine:
    """
    20-step simulation integrating all CityMind modules.
    Single shared CityGraph — all changes propagate instantly.
    """

    TOTAL_STEPS = 20
    FLOOD_PROBABILITY = 0.25   # Chance per step of a road flooding
    UNBLOCK_PROBABILITY = 0.15 # Chance per step of a flood clearing

    def __init__(self, rows: int = 10, cols: int = 10):
        self.city = CityGraph(rows, cols)
        self.step_num = 0
        self.running = False
        self.paused = False
        self.done = False

        # Module instances
        self.layout_planner  = LayoutPlanner(self.city)
        self.road_optimizer  = RoadOptimizer(self.city)
        self.ambulance_placer= AmbulancePlacer(self.city)
        self.router          = DynamicRouter(self.city)
        self.crime_predictor = CrimeRiskPredictor(self.city)

        # State tracking
        self.ambulance_positions: List[int] = []
        self.blocked_roads: List[tuple] = []
        self.simulation_log: List[Dict] = []
        self.road_optimizer_result: Dict = {}
        self.crime_result: Dict = {}
        self.layout_valid: bool = False
        self.initialized: bool = False

        # Callback for UI updates
        self._step_callback: Optional[Callable] = None

    def initialize(self):
        """Run all initialization phases before the 20-step simulation."""
        self.city.log("=" * 60)
        self.city.log("🌆  CITYMIND INITIALIZATION STARTED")
        self.city.log("=" * 60)

        # Phase 1: Layout (CSP)
        self.city.log("\n📌 PHASE 1: City Layout Planning (CSP)")
        success = self.layout_planner.plan()
        self.layout_valid, violations = self.layout_planner.validate_layout()
        if violations:
            for v in violations[:5]:
                self.city.log(f"   {v}")

        # Phase 2: Road Network (MST)
        self.city.log("\n📌 PHASE 2: Road Network Optimization (Kruskal's MST)")
        self.road_optimizer_result = self.road_optimizer.optimize()

        # Phase 3 (deferred): Ambulance placement runs after crime prediction
        # Phase 5: Crime Risk ML pipeline
        self.city.log("\n📌 PHASE 5: Crime Risk Prediction (K-Means + Random Forest)")
        self.crime_result = self.crime_predictor.run_pipeline()

        # Phase 3: Ambulance Placement (after risk weights set)
        self.city.log("\n📌 PHASE 3: Ambulance Placement (Genetic Algorithm)")
        self.ambulance_positions = self.ambulance_placer.place()

        # Phase 4: Initialize emergency router
        self.city.log("\n📌 PHASE 4: Emergency Router Initialized (A*)")
        civilians = self._find_civilian_targets()
        start_node = self._find_start_node()
        if start_node is not None and civilians:
            self.router.initialize(start_node, civilians)

        self.initialized = True
        self.city.log("\n✅  ALL PHASES COMPLETE — Starting 20-step simulation")
        self.city.log("=" * 60)

    def _find_start_node(self) -> Optional[int]:
        """Ambulance depot as starting point for emergency team."""
        depots = self.city.all_nodes_of_type(LocationType.AMBULANCE_DEPOT)
        return depots[0] if depots else 0

    def _find_civilian_targets(self) -> List[int]:
        """Pick 4 random residential nodes as trapped civilians."""
        res_nodes = self.city.all_nodes_of_type(LocationType.RESIDENTIAL)
        if not res_nodes:
            res_nodes = list(self.city.G.nodes())
        k = min(4, len(res_nodes))
        return random.sample(res_nodes, k)

    def step(self) -> Dict:
        """
        Execute one simulation step.
        Returns full state snapshot for UI.
        """
        if not self.initialized:
            self.initialize()

        if self.done or self.step_num >= self.TOTAL_STEPS:
            self.done = True
            self.city.log("🏁 Simulation complete!")
            return self._snapshot()

        self.step_num += 1
        self.city.log(f"\n─── STEP {self.step_num}/{self.TOTAL_STEPS} ─────────────")

        # Event 1: Random flooding
        if random.random() < self.FLOOD_PROBABILITY:
            self._flood_random_road()

        # Event 2: Random road clearing
        if self.blocked_roads and random.random() < self.UNBLOCK_PROBABILITY:
            self._clear_random_road()

        # Event 3: Advance emergency router
        router_state = self.router.step()
        if router_state.get("done"):
            self.city.log("✅  All civilians rescued!")

        # Event 4: Every 5 steps, re-evaluate ambulance placement
        if self.step_num % 5 == 0:
            self.city.log("🔄 Re-evaluating ambulance placement...")
            self.ambulance_placer._dist_cache.clear()
            new_positions = self.ambulance_placer.place()
            if new_positions != self.ambulance_positions:
                self.ambulance_positions = new_positions
                self.city.log(f"   New positions: {new_positions}")

        # Event 5: Every 7 steps, update risk from patrol data
        if self.step_num % 7 == 0:
            self._update_risk_from_patrol()

        if self.step_num >= self.TOTAL_STEPS:
            self.done = True

        snap = self._snapshot()
        self.simulation_log.append(snap)
        return snap

    def _flood_random_road(self):
        """Block a random non-blocked road (flooding event)."""
        edges = [
            (u, v) for u, v, d in self.city.G.edges(data=True)
            if not d['blocked']
        ]
        if not edges:
            return
        u, v = random.choice(edges)
        self.city.block_road(u, v, reason="Flood")
        self.blocked_roads.append((u, v))
        # Notify router immediately
        self.router.notify_road_blocked(u, v)

    def _clear_random_road(self):
        """Unblock a previously blocked road."""
        u, v = random.choice(self.blocked_roads)
        self.city.unblock_road(u, v)
        self.blocked_roads = [(a, b) for a, b in self.blocked_roads
                              if not (a == u and b == v)]

    def _update_risk_from_patrol(self):
        """Slightly randomize risk indices to simulate patrol-gathered intelligence."""
        for nid in random.sample(list(self.city.G.nodes()), k=5):
            current_risk = self.city.G.nodes[nid]['risk_index']
            new_risk = max(0.0, min(1.0, current_risk + random.uniform(-0.1, 0.1)))
            label = "High" if new_risk > 0.66 else ("Medium" if new_risk > 0.33 else "Low")
            self.city.set_risk(nid, new_risk, label)

    def _snapshot(self) -> Dict:
        """Full state snapshot for UI rendering."""
        return {
            "step": self.step_num,
            "total_steps": self.TOTAL_STEPS,
            "done": self.done,
            "nodes": self.city.get_node_data(),
            "edges": self.city.get_edge_data(),   
            "ambulances": self.ambulance_positions,
            "router": self.router.get_status(),
            "blocked_roads": list(self.blocked_roads),
            "log": self.city.get_log(30),
            "crime_distribution": self.crime_result.get("risk_distribution", {}),
            "police_deployment": self.crime_result.get("police_deployment", []),
            "clusters": self.crime_result.get("clusters", {}),
        }

    def reset(self, rows: int = 10, cols: int = 10):
        """Full reset of the simulation."""
        self.__init__(rows, cols)

    def get_full_log(self) -> List[str]:
        return self.city.get_log(200)
