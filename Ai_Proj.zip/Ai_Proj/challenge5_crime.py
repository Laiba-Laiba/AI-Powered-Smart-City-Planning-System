"""
Challenge 5: Crime Risk Prediction and Integration
Step 1: K-Means Clustering (Unsupervised) — groups neighborhoods by features
Step 2: Random Forest Classification (Supervised) — predicts risk level
Why different? Clustering needs no labels (no ground truth exists).
Classification needs labels (we generate synthetic data from our domain logic).
Integration: risk labels update city graph edge weights → affects routing & ambulance placement.
"""
import random
import math
import numpy as np
from typing import Dict, List, Tuple
from city_graph import CityGraph, LocationType

try:
    from sklearn.cluster import KMeans
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import classification_report
    SKLEARN_OK = True
except ImportError:
    SKLEARN_OK = False


RISK_LABELS = ["Low", "Medium", "High"]
NUM_CLUSTERS = 3
NUM_POLICE   = 10


class CrimeRiskPredictor:
    """
    Two-stage ML pipeline:
    1. K-Means: cluster neighborhoods (unsupervised)
    2. Random Forest: classify crime risk (supervised, synthetic data)
    """

    def __init__(self, city: CityGraph):
        self.city = city
        self.scaler = StandardScaler() if SKLEARN_OK else None
        self.kmeans = None
        self.rf_model = None
        self.node_features: np.ndarray = None
        self.node_ids: List[int] = []
        self.predictions: Dict[int, str] = {}
        self.cluster_assignments: Dict[int, int] = {}
        self.police_deployment: List[int] = []

    def run_pipeline(self) -> Dict:
        """Full ML pipeline: features → cluster → synthesize labels → train → predict → deploy."""
        self.city.log("🔍  Starting Crime Risk Prediction Pipeline...")

        # Step 1: Extract features
        self._extract_features()

        # Step 2: K-Means clustering (unsupervised)
        self._kmeans_cluster()

        # Step 3: Generate synthetic crime labels (domain knowledge)
        labels = self._generate_synthetic_labels()

        # Step 4: Train Random Forest (supervised)
        self._train_classifier(labels)

        # Step 5: Predict risk for all nodes
        self._predict_all()

        # Step 6: Update city graph with risk weights
        self._update_city_graph()

        # Step 7: Deploy police officers
        self._deploy_police()

        self.city.log("✅  Crime risk pipeline complete. City graph weights updated.")

        return {
            "predictions": self.predictions,
            "clusters": self.cluster_assignments,
            "police_deployment": self.police_deployment,
            "risk_distribution": self._risk_distribution(),
        }

    def _extract_features(self):
        """
        Feature vector per node:
        [population_density, industrial_proximity, location_type_encoded, row, col]
        """
        self.node_ids = list(self.city.G.nodes())
        industrials = self.city.all_nodes_of_type(LocationType.INDUSTRIAL)

        features = []
        for nid in self.node_ids:
            data = self.city.G.nodes[nid]

            # Population density (normalized later)
            pop = data['population_density']

            # Proximity to nearest industrial zone (inverse)
            if industrials:
                min_ind_dist = min(
                    self.city.bfs_distance(nid, ind) for ind in industrials
                )
            else:
                min_ind_dist = 99

            # Location type encoded numerically
            type_enc = {
                LocationType.RESIDENTIAL:    3,
                LocationType.INDUSTRIAL:     5,
                LocationType.SCHOOL:         2,
                LocationType.HOSPITAL:       1,
                LocationType.POWER_PLANT:    4,
                LocationType.AMBULANCE_DEPOT:1,
                LocationType.EMPTY:          0,
            }.get(data['location_type'], 0)

            row, col = data['row'], data['col']

            features.append([pop, min_ind_dist, type_enc, row, col])

        self.node_features = np.array(features, dtype=float)

    def _kmeans_cluster(self):
        """
        K-Means Clustering (Unsupervised):
        Groups nodes into NUM_CLUSTERS clusters based on feature similarity.
        No labels needed — discovers natural groupings.
        """
        if not SKLEARN_OK:
            self.city.log("⚠️  scikit-learn not available, using manual K-means.")
            self._manual_kmeans()
            return

        scaled = self.scaler.fit_transform(self.node_features)
        self.kmeans = KMeans(n_clusters=NUM_CLUSTERS, random_state=42, n_init=10)
        cluster_labels = self.kmeans.fit_predict(scaled)

        for i, nid in enumerate(self.node_ids):
            self.cluster_assignments[nid] = int(cluster_labels[i])
            self.city.G.nodes[nid]['cluster_id'] = int(cluster_labels[i])

        self.city.log(f"📊 K-Means: {NUM_CLUSTERS} clusters identified.")

    def _manual_kmeans(self):
        """Fallback K-means without sklearn."""
        k = NUM_CLUSTERS
        n = len(self.node_ids)
        indices = list(range(n))
        centroids = [self.node_features[i] for i in random.sample(indices, k)]

        for _ in range(50):
            clusters = [[] for _ in range(k)]
            assignments = []
            for feat in self.node_features:
                dists = [np.linalg.norm(feat - c) for c in centroids]
                cl = int(np.argmin(dists))
                clusters[cl].append(feat)
                assignments.append(cl)
            new_centroids = []
            for cl_idx, members in enumerate(clusters):
                if members:
                    new_centroids.append(np.mean(members, axis=0))
                else:
                    new_centroids.append(centroids[cl_idx])
            if all(np.allclose(c, n) for c, n in zip(centroids, new_centroids)):
                break
            centroids = new_centroids

        for i, nid in enumerate(self.node_ids):
            self.cluster_assignments[nid] = assignments[i]
            self.city.G.nodes[nid]['cluster_id'] = assignments[i]

    def _generate_synthetic_labels(self) -> List[str]:
        """
        Domain-logic crime label generation:
        - High density + near industrial → High risk
        - Moderate density or industrial proximity → Medium
        - Low density, far from industrial → Low
        This simulates real-world crime correlation with socioeconomic factors.
        """
        labels = []
        for i, nid in enumerate(self.node_ids):
            pop  = self.node_features[i][0]
            ind_dist = self.node_features[i][1]
            ltype = self.city.G.nodes[nid]['location_type']

            score = 0
            # High population → more crime opportunities
            if pop > 1200:
                score += 3
            elif pop > 600:
                score += 2
            else:
                score += 0

            # Near industrial → pollution, socioeconomic stress
            if ind_dist <= 1:
                score += 4
            elif ind_dist <= 3:
                score += 2
            elif ind_dist <= 5:
                score += 1

            # Location type modifiers
            if ltype == LocationType.INDUSTRIAL:
                score += 2
            elif ltype == LocationType.HOSPITAL:
                score -= 2
            elif ltype == LocationType.SCHOOL:
                score += 1

            # Some noise for realism
            score += random.randint(-1, 1)

            if score >= 6:
                labels.append("High")
            elif score >= 3:
                labels.append("Medium")
            else:
                labels.append("Low")

        highs   = labels.count("High")
        mediums = labels.count("Medium")
        lows    = labels.count("Low")
        self.city.log(
            f"📋 Synthetic labels: High={highs}, Medium={mediums}, Low={lows}"
        )
        return labels

    def _train_classifier(self, labels: List[str]):
        """
        Train Random Forest classifier (Supervised Learning).
        Features: node properties. Target: crime risk label.
        Random Forest chosen for:
        - Handles mixed feature types well
        - Robust to outliers
        - Provides feature importance
        """
        if not SKLEARN_OK:
            self.city.log("⚠️  sklearn unavailable — using rule-based fallback.")
            self._labels_fallback = labels
            return

        X = self.scaler.transform(self.node_features)
        y = labels

        self.rf_model = RandomForestClassifier(
            n_estimators=100,
            max_depth=8,
            random_state=42,
            class_weight='balanced'
        )
        self.rf_model.fit(X, y)

        # Feature importance log
        importances = self.rf_model.feature_importances_
        feat_names = ["population", "ind_proximity", "type_enc", "row", "col"]
        imp_str = ", ".join(
            f"{n}={v:.2f}" for n, v in zip(feat_names, importances)
        )
        self.city.log(f"🌲 Random Forest trained. Feature importances: {imp_str}")

    def _predict_all(self):
        """Predict risk level for all nodes."""
        if not SKLEARN_OK:
            for i, nid in enumerate(self.node_ids):
                self.predictions[nid] = getattr(self, '_labels_fallback', ["Low"] * 999)[i]
            return

        X = self.scaler.transform(self.node_features)
        preds = self.rf_model.predict(X)
        for i, nid in enumerate(self.node_ids):
            self.predictions[nid] = preds[i]

    def _update_city_graph(self):
        """
        Feed predictions back into city graph.
        High risk → risk_index = 0.9, Medium → 0.5, Low → 0.1
        This updates edge costs via set_risk().
        """
        risk_values = {"High": 0.9, "Medium": 0.5, "Low": 0.1}
        for nid, label in self.predictions.items():
            idx = risk_values.get(label, 0.3)
            self.city.set_risk(nid, idx, label)

    def _deploy_police(self):
        """
        Deploy police officers to High-risk nodes.
        Sort High-risk by population density, assign top-N.
        """
        high_risk = [(nid, self.city.G.nodes[nid]['population_density'])
                     for nid, label in self.predictions.items()
                     if label == "High"]
        high_risk.sort(key=lambda x: -x[1])

        self.police_deployment = [nid for nid, _ in high_risk[:NUM_POLICE]]

        # Fallback: if fewer than NUM_POLICE high-risk nodes, add medium risk
        if len(self.police_deployment) < NUM_POLICE:
            medium_risk = [
                (nid, self.city.G.nodes[nid]['population_density'])
                for nid, label in self.predictions.items()
                if label == "Medium" and nid not in self.police_deployment
            ]
            medium_risk.sort(key=lambda x: -x[1])
            needed = NUM_POLICE - len(self.police_deployment)
            self.police_deployment += [nid for nid, _ in medium_risk[:needed]]

        self.city.log(
            f"👮  {len(self.police_deployment)} officers deployed to high-risk zones."
        )

    def _risk_distribution(self) -> Dict:
        dist = {"High": 0, "Medium": 0, "Low": 0}
        for label in self.predictions.values():
            if label in dist:
                dist[label] += 1
        return dist

    def get_cluster_summary(self) -> List[Dict]:
        """Summary of each cluster."""
        summaries = []
        for cl_id in range(NUM_CLUSTERS):
            members = [nid for nid, c in self.cluster_assignments.items() if c == cl_id]
            if not members:
                continue
            avg_pop = sum(self.city.G.nodes[n]['population_density'] for n in members) / len(members)
            risk_counts = {"High": 0, "Medium": 0, "Low": 0}
            for n in members:
                label = self.predictions.get(n, "Unknown")
                if label in risk_counts:
                    risk_counts[label] += 1
            summaries.append({
                "cluster": cl_id,
                "size": len(members),
                "avg_population": round(avg_pop, 1),
                "risk_counts": risk_counts,
            })
        return summaries
