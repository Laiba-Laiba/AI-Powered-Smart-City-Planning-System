# CityMind — Intelligent Urban Decision System

## Algorithms Used
| Challenge | Algorithm | Why |
|-----------|-----------|-----|
| 1. Layout Planning | CSP + Backtracking | Variables, domains, constraints |
| 2. Road Network | Kruskal's MST + Redundancy | Min-cost connected graph |
| 3. Ambulance Placement | Genetic Algorithm | Large search space, minimax fitness |
| 4. Emergency Routing | A* with Dynamic Replanning | Optimal path, admissible heuristic |
| 5. Crime Risk | K-Means + Random Forest | Unsupervised cluster + supervised classify |

## How to Run
```bash
pip install -r requirements.txt
python main.py           # Web UI at http://localhost:5000
python main.py --console # Console demo
```

## File Structure
- `city_graph.py`      — Shared single source of truth
- `challenge1_layout.py`  — CSP layout planner
- `challenge2_roads.py`   — MST road optimizer  
- `challenge3_ambulance.py` — Genetic Algorithm ambulance placer
- `challenge4_routing.py` — A* dynamic router
- `challenge5_crime.py`   — K-Means + Random Forest ML pipeline
- `simulation.py`      — 20-step integrated simulation engine
- `app.py`            — Flask web server
- `main.py`           — Launcher
- `templates/index.html` — Interactive dashboard
