let logCache = [];
let running = false;
let currentSnapshot = null;
let currentView = "combined";

async function initializeSim() {
  const res = await fetch('/api/initialize', { method: 'POST' });
  const data = await res.json();
  logCache = [];
  currentSnapshot = data.snapshot;
  render(data.snapshot);
}

async function stepSim() {
  const res = await fetch('/api/step', { method: 'POST' });
  const data = await res.json();
  currentSnapshot = data.snapshot;
  render(data.snapshot);
}

async function resetSim() {
  await fetch('/api/reset', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ rows: 10, cols: 10 })
  });

  document.getElementById('grid').innerHTML = '';
  document.getElementById('logs').innerHTML = '';
  document.getElementById('stats').innerHTML = '';
  document.getElementById('roadInfo').innerHTML = '';
  document.getElementById('edgeLayer').innerHTML = '';
  logCache = [];
  currentSnapshot = null;
}

async function startAuto() {
  running = true;
  while (running) {
    await stepSim();
    await new Promise(r => setTimeout(r, 600));
  }
}

function stopAuto() {
  running = false;
}

function setView(view) {
  currentView = view;
  document.getElementById('overlayStatus').innerText =
    view.charAt(0).toUpperCase() + view.slice(1) + " View";
  if (currentSnapshot) render(currentSnapshot);
}

function colorForType(type) {
  return {
    Residential: "#1e3a8a",
    Hospital: "#b91c1c",
    School: "#f59e0b",
    Industrial: "#374151",
    PowerPlant: "#7c3aed",
    AmbulanceDepot: "#10b981",
    Empty: "#0f172a"
  }[type] || "#111";
}

function riskColor(label) {
  if (label === "High") return "#7f1d1d";
  if (label === "Medium") return "#92400e";
  return "#1e3a8a";
}

function ambulanceCoverageColor(dist) {
  if (dist <= 1) return "#22c55e";
  if (dist <= 2) return "#4ade80";
  if (dist <= 3) return "#86efac";
  return null;
}

/* ---------- TEXT CONTRAST HELPERS ---------- */

function isLightCoverageColor(cell) {
  const bg = cell.style.background || "";
  return (
    bg.includes("#22c55e") ||
    bg.includes("#4ade80") ||
    bg.includes("#86efac")
  );
}

/* ---------- RENDER ---------- */

function render(snapshot) {
  const grid = document.getElementById('grid');
  const edgeLayer = document.getElementById('edgeLayer');

  if (grid.children.length === 0) {
    snapshot.nodes.forEach(n => {
      const div = document.createElement('div');
      div.classList.add('cell');
      div.id = "node-" + n.id;
      grid.appendChild(div);
    });
  }

  snapshot.nodes.forEach(n => {
    const cell = document.getElementById("node-" + n.id);
    let icon = "⬜";

    if (n.type === "Hospital") icon = "🏥";
    else if (n.type === "School") icon = "🏫";
    else if (n.type === "Industrial") icon = "🏭";
    else if (n.type === "PowerPlant") icon = "⚡";
    else if (n.type === "AmbulanceDepot") icon = "🚑";

    if (n.risk_label === "High") icon = "🔥";
    if (snapshot.ambulances.includes(n.id)) icon = "🚑";

    /* ---------- COLOR REASON ---------- */
    let colorReason = "";

    if (currentView === "heatmap") {
      colorReason = `Risk: ${n.risk_label}`;
    }
    else if (currentView === "coverage") {
      const d = nearestAmbulanceDistance(n.id, snapshot);
      colorReason = `Distance: ${d}`;
    }
    else if (currentView === "combined") {
      if (n.risk_label === "High") colorReason = "High Risk Zone";
      else if (n.risk_label === "Medium") colorReason = "Medium Risk Zone";
      else if (snapshot.ambulances.includes(n.id)) colorReason = "Ambulance Position";
      else colorReason = "Normal Node";
    }
    else {
      colorReason = `Type: ${n.type}`;
    }

    /* ---------- CELL CONTENT ---------- */
    cell.innerHTML = `
      <div class="id">${n.id}</div>
      <div class="icon">${icon}</div>
      <div class="meta">${colorReason}</div>
    `;

    cell.title = colorReason;
    cell.className = "cell";

    /* ---------- BACKGROUND ---------- */
    cell.style.background = colorForType(n.type);

    if (currentView === "heatmap") {
      cell.style.background = riskColor(n.risk_label);
    }

    if (currentView === "coverage" && snapshot.ambulances.length > 0) {
      const d = nearestAmbulanceDistance(n.id, snapshot);
      const c = ambulanceCoverageColor(d);
      if (c) cell.style.background = c;
    }

    if (currentView === "combined") {
      if (n.risk_label === "High") cell.style.background = "#7f1d1d";
      if (n.risk_label === "Medium") cell.style.background = "#92400e";
      if (snapshot.ambulances.includes(n.id)) cell.style.background = "#065f46";
    }

    /* ---------- TEXT CONTRAST FIX ---------- */
    const meta = cell.querySelector(".meta");

    if (currentView === "coverage" && isLightCoverageColor(cell)) {
      cell.style.color = "#000";
      if (meta) meta.style.color = "#000";
    } else {
      cell.style.color = "#fff";
      if (meta) meta.style.color = "#fff";
    }

    if (snapshot.blocked_roads?.some(([u, v]) => sameEdge(u, v, n.id))) {
      cell.classList.add("blocked-node");
    }
  });

  drawEdges(snapshot);
  updateStats(snapshot);
  updateLogs(snapshot);
  updateRoadInfo(snapshot);
}

/* ---------- HELPERS ---------- */

function nearestAmbulanceDistance(nodeId, snapshot) {
  if (!snapshot.ambulances || snapshot.ambulances.length === 0) return 999;

  const node = snapshot.nodes.find(n => n.id === nodeId);
  if (!node) return 999;

  let best = 999;

  snapshot.nodes.forEach(n => {
    if (snapshot.ambulances.includes(n.id)) {
      const d = Math.abs(n.row - node.row) + Math.abs(n.col - node.col);
      if (d < best) best = d;
    }
  });

  return best;
}

function sameEdge(u, v, nodeId) {
  return u === nodeId || v === nodeId;
}

/* ---------- EDGES ---------- */

function drawEdges(snapshot) {
  const svg = document.getElementById("edgeLayer");
  svg.innerHTML = "";

  const gridRect = document.getElementById("grid").getBoundingClientRect();
  svg.setAttribute("width", gridRect.width);
  svg.setAttribute("height", gridRect.height);

  if (currentView === "coverage" || currentView === "heatmap") return;

  (snapshot.edges || []).forEach(e => {
    const uCell = document.getElementById("node-" + e.u);
    const vCell = document.getElementById("node-" + e.v);
    if (!uCell || !vCell) return;

    const r1 = uCell.getBoundingClientRect();
    const r2 = vCell.getBoundingClientRect();

    const x1 = r1.left + r1.width / 2 - gridRect.left;
    const y1 = r1.top + r1.height / 2 - gridRect.top;
    const x2 = r2.left + r2.width / 2 - gridRect.left;
    const y2 = r2.top + r2.height / 2 - gridRect.top;

    const line = document.createElementNS("http://www.w3.org/2000/svg", "line");

    line.setAttribute("x1", x1);
    line.setAttribute("y1", y1);
    line.setAttribute("x2", x2);
    line.setAttribute("y2", y2);

    line.setAttribute("stroke", e.blocked ? "#ef4444" : "#64748b");
    line.setAttribute("stroke-width", e.blocked ? "4" : "2");
    line.setAttribute("stroke-dasharray", e.blocked ? "6 4" : "0");

    svg.appendChild(line);
  });
}

/* ---------- UI ---------- */

function updateStats(snapshot) {
  document.getElementById('stats').innerHTML = `
    <h3>Step: ${snapshot.step} / ${snapshot.total_steps}</h3>
    <p>🚑 Ambulances: ${snapshot.ambulances.join(', ')}</p>
    <p>🚨 Rescued: ${snapshot.router?.rescued?.length || 0}</p>
  `;
}

function updateRoadInfo(snapshot) {
  const router = snapshot.router || {};
  document.getElementById('roadInfo').innerHTML = `
    <p><b>Router:</b> ${router.current_node ?? '-'}</p>
    <p><b>Target:</b> ${router.current_target ?? '-'}</p>
    <p><b>Blocked:</b> ${snapshot.blocked_roads?.length || 0}</p>
  `;
}

function updateLogs(snapshot) {
  const logBox = document.getElementById('logs');

  (snapshot.log || []).forEach(line => {
    if (!logCache.includes(line)) {
      logCache.push(line);
      const div = document.createElement("div");
      div.className = "log-entry";
      div.innerText = line;
      logBox.appendChild(div);
    }
  });

  logBox.scrollTop = logBox.scrollHeight;
}